# portfolio
*NOTE: This is an old project. I am leaving it here for people to use as a
template but I do not plan to host it anywhere or maintain it in the future.*

My developer portfolio page

## Running locally
```
npm install
npm start
```
